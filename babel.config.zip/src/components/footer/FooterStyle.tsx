import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    backgroundColor:"#5880b3",
    height: 110,
    alignItems:'center',
    justifyContent:'center'
  },
  text: {
    fontSize:20,
    fontWeight:'600'
  }
});