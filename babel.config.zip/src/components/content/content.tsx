import React, { useState } from 'react';
import { View, Text, Button } from 'react-native';

import {styles} from './ContentStyle'

export function Content() {
    const [Indice, setIndice] = useState(0);





    function contadorSoma(){
        if(Indice >= 0){
            setIndice(Indice+1)
        }
    }
    function contadorSubtracao(){
        if(Indice > 0){
            setIndice(Indice-1)
        }
    }

  return (
    <View style={styles.container}>
        <Text> {Indice} </Text>

        <Button onPress={contadorSoma} title='+'/>
        <Button onPress ={contadorSubtracao} title='-'/>
        
    </View>
  );
}